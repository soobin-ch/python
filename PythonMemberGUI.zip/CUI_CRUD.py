# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version Jun 17 2015)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc

import pymssql
import pickle

with open('mssqldb.dat','rb') as obj:
    config =pickle.load(obj)
###########################################################################
## Class MyFrame1
###########################################################################

class MyFrame1(wx.Frame):

    def __init__(self, parent):
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title=wx.EmptyString, pos=wx.DefaultPosition,
                          size=wx.Size(500, 353), style=wx.DEFAULT_FRAME_STYLE | wx.TAB_TRAVERSAL)



        bSizer1 = wx.BoxSizer(wx.VERTICAL)

        self.m_panel1 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer2 = wx.BoxSizer(wx.HORIZONTAL)

        self.m_staticText1 = wx.StaticText(self.m_panel1, wx.ID_ANY, u"번호:", wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_staticText1.Wrap(-1)
        bSizer2.Add(self.m_staticText1, 0, wx.ALL, 5)

        self.txtNo = wx.TextCtrl(self.m_panel1, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer2.Add(self.txtNo, 0, wx.ALL, 5)

        self.btnInsert = wx.Button(self.m_panel1, wx.ID_ANY, u"등록", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer2.Add(self.btnInsert, 0, wx.ALL, 5)

        self.m_panel1.SetSizer(bSizer2)
        self.m_panel1.Layout()
        bSizer2.Fit(self.m_panel1)
        bSizer1.Add(self.m_panel1, 1, wx.EXPAND | wx.ALL, 5)

        self.m_panel2 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer3 = wx.BoxSizer(wx.HORIZONTAL)

        self.m_staticText2 = wx.StaticText(self.m_panel2, wx.ID_ANY, u"이름:", wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_staticText2.Wrap(-1)
        bSizer3.Add(self.m_staticText2, 0, wx.ALL, 5)

        self.txtName = wx.TextCtrl(self.m_panel2, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer3.Add(self.txtName, 0, wx.ALL, 5)

        self.btnUpdate = wx.Button(self.m_panel2, wx.ID_ANY, u"수정", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer3.Add(self.btnUpdate, 0, wx.ALL, 5)

        self.btnConfirm = wx.Button(self.m_panel2, wx.ID_ANY, u"확인", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer3.Add(self.btnConfirm, 0, wx.ALL, 5)

        self.m_panel2.SetSizer(bSizer3)
        self.m_panel2.Layout()
        bSizer3.Fit(self.m_panel2)
        bSizer1.Add(self.m_panel2, 1, wx.EXPAND | wx.ALL, 5)

        self.m_panel3 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer4 = wx.BoxSizer(wx.HORIZONTAL)

        self.m_staticText3 = wx.StaticText(self.m_panel3, wx.ID_ANY, u"전화:", wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_staticText3.Wrap(-1)
        bSizer4.Add(self.m_staticText3, 0, wx.ALL, 5)

        self.txtTel = wx.TextCtrl(self.m_panel3, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer4.Add(self.txtTel, 0, wx.ALL, 5)

        self.btnDelete = wx.Button(self.m_panel3, wx.ID_ANY, u"삭제", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer4.Add(self.btnDelete, 0, wx.ALL, 5)

        self.m_panel3.SetSizer(bSizer4)
        self.m_panel3.Layout()
        bSizer4.Fit(self.m_panel3)
        bSizer1.Add(self.m_panel3, 1, wx.EXPAND | wx.ALL, 5)

        self.m_panel4 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer5 = wx.BoxSizer(wx.HORIZONTAL)

        bSizer5.SetMinSize(wx.Size(0, 0))
        self.lstMember = wx.ListCtrl(self.m_panel4, wx.ID_ANY, wx.DefaultPosition, wx.Size(400, 100), wx.LC_REPORT)
        bSizer5.Add(self.lstMember, 0, wx.ALL, 5)

        self.m_panel4.SetSizer(bSizer5)
        self.m_panel4.Layout()
        bSizer5.Fit(self.m_panel4)
        bSizer1.Add(self.m_panel4, 1, wx.EXPAND | wx.ALL, 5)

        self.m_panel5 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer6 = wx.BoxSizer(wx.HORIZONTAL)

        self.m_staticText4 = wx.StaticText(self.m_panel5, wx.ID_ANY, u"인원수:", wx.DefaultPosition, wx.DefaultSize, 0)
        self.m_staticText4.Wrap(-1)
        bSizer6.Add(self.m_staticText4, 0, wx.ALL, 5)

        self.lblCnt = wx.StaticText(self.m_panel5, wx.ID_ANY, u"0", wx.DefaultPosition, wx.DefaultSize, 0)
        self.lblCnt.Wrap(-1)
        bSizer6.Add(self.lblCnt, 0, wx.ALL, 5)

        self.m_panel5.SetSizer(bSizer6)
        self.m_panel5.Layout()
        bSizer6.Fit(self.m_panel5)
        bSizer1.Add(self.m_panel5, 1, wx.EXPAND | wx.ALL, 5)

        self.SetSizer(bSizer1)
        self.Layout()

        self.Centre(wx.BOTH)

        self.lstMember.InsertColumn(0, '', width=50)
        self.lstMember.InsertColumn(1, '0', width=100)
        self.lstMember.InsertColumn(2, '', width=150)


 # 버튼의 id 설정: Event 처리시 어느 버튼 클릭했는지 확인
        self.btnInsert.id = 1

        self.btnUpdate.id = 2  # 실행 중에 id를 변경. 이유는 수정:2, 취소: 5 두 가지 작업을 함
        self.btnConfirm.id = 3

        self.btnDelete.id = 4


        self.btnInsert.Bind(wx.EVT_BUTTON, self.btnProcess)
        self.btnUpdate.Bind(wx.EVT_BUTTON, self.btnProcess)
        self.btnConfirm.Bind(wx.EVT_BUTTON, self.btnProcess)
        self.btnDelete.Bind(wx.EVT_BUTTON, self.btnProcess)

        self.btnConfirm.Enable(enable=False)
        self.showData()

    def showData(self):
        try:
                conn = pymssql.connect(**config)
                cursor = conn.cursor()
                sql = "select * from pymem"
                cursor.execute(sql)
                self.lstMember.DeleteAllItems()  # 1st Member

                count = 0
                for data in cursor:
                    i = self.lstMember.InsertItem(10000, 0)  # 동적인 번호 부여 (65535 까지 가능)
                    self.lstMember.SetItem(i, 0, str(data[0]))  # print(data[1])
                    self.lstMember.SetItem(i, 1, data[1])  # 0/print(data[2])
                    self.lstMember.SetItem(i, 2, data[2])  # Met
                    count += 1  # 인원수 누적

                self.lblCnt.SetLabel(str(count))

        except Exception as e:
                wx.MessageBox('읽기 오류', '에러 :' + str(e), wx.OK)
        finally:
                cursor.close()  # 작업이 끝난 객체 해제
                conn.close()

    def btnProcess(self, event):
            id = event.GetEventObject().id

            if id == 1:
                self.memInsert()
            elif id == 2:
                self.memUpdateReady() # 5 /
                # self.memUpdateReady()
            elif id == 3:
                self.memUpdateProcess()  # (5)
            elif id == 4:
                self.memDelete()  # 42:
            elif id == 5:
                self.memUpdateCancel()
                #

    def selectData(self, no):

            try:

                conn = pymssql.connect(**config)

                cursor = conn.cursor()

                sql = "select * from pymem where no={0}".format(no)

                cursor.execute(sql)

                data = cursor.fetchone()
                # print(data) # 있으면 tuple로 보이고, 없으면 None

                return data

            except Exception as e:

                wx.MessageBox('행읽기 오류:' + str(e), '에러', wx.OK)

            finally:
                cursor.close()
                conn.close()

    def memInsert(self):

            no = self.txtNo.GetValue()


            name = self.txtName.GetValue()

            tel = self.txtTel.GetValue()


            if no == '' or name == '' or tel == '':

                wx.MessageBox('자료를 입렧하시오', '알림', wx.OK)

                return
            try:

                data = self.selectData(no)

                if data != None:
                    wx.MessageBox('이미 등록된 번호입니다', '알림', wx.OK)
                    self.txtNo.SetFocus()
                    return
                conn = pymssql.connect(**config)

                cursor = conn.cursor()

                sql = "insert into pymem values (%s,%s,%s)"

                cursor.execute(sql, (no, name, tel))

                conn.commit()  # 550E

                self.showData()
                self.txtNo.SetValue('')
                self.txtName.SetValue('')

                self.txtTel.SetValue('')

            except Exception as e:

                wx.MessageBox('추가오류:' + str(e), '에러', wx.OK)
                conn.rollback()  # DB에 입력작업 취소

            finally:

                cursor.close()
                conn.close()

    def memUpdateReady(self):

            textDlg = wx.TextEntryDialog(None, '수정할 번호를 입력하시오','알림')

            if textDlg.ShowModal() == wx.ID_OK:

                if textDlg.GetValue() == '':
                    textDlg.Destroy()
                    return

                upno = textDlg.GetValue()

                data = self.selectData(upno)

                if data == None:
                    wx.MessageBox(upno + "번은 등록된 자료가 아닙니다","알림", wx.OK)

                    textDlg.Destroy()
                    return

                self.txtNo.SetValue(str(data[0]))  # #

                self.txtName.SetValue(data[1])

                self.txtTel.SetValue(data[2])

                self.txtNo.SetEditable(False)  # Primary key

                self.btnUpdate.SetLabel('')  # 4 #15 +5

                self.btnUpdate.id = 5  # id # 2958

                self.btnConfirm.Enable(enable=True)

            textDlg.Destroy()

    def memUpdateProcess(self):

            no = self.txtNo.GetValue()

            name = self.txtName.GetValue()

            tel = self.txtTel.GetValue()

            if name =='' or tel =='' :

                wx.MessageBox('수정 자료를 입력하시오','알림',wx.OK)
                return

            try:
                conn = pymssql.connect(**config)
                cursor = conn.cursor()
                sql = "update pymem set name=%s, tel=%s where no=%s"
                cursor.execute(sql, (name, tel, no))
                conn.commit()
                self.showData()  # E
                self.memUpdateCancel()  ###

            except Exception as e:
                wx.MessageBox('수정에러'+ str(e), '알림', wx.OK)
                conn.rollback()

            finally:
                cursor.close()
                conn.close()

    def memUpdateCancel(self):

            self.txtNo.SetValue('')


            self.txtName.SetValue('')

            self.txtTel.SetValue('')

            self.txtNo.SetEditable(True)

            self.btnUpdate.SetLabel('수정')

            self.btnUpdate.id = 2

            self.btnConfirm.Enable(enable=False)

            # 회원 삭제

    def memDelete(self):

        textDlg = wx.TextEntryDialog(None, '삭제할 번호를 입력하시오','알림')

        if textDlg.ShowModal() == wx.ID_OK:
            if textDlg.GetValue() =='':
                textDlg.Destroy()
                return

            delno = textDlg.GetValue()

            data = self.selectData(delno)

            if data == None:
                wx.MessageBox(delno + "번은 등록된 자료가 아닙니다", "알림", wx.OK)
                textDlg.Destroy()
                return

        # 삭제 작업 계속 진행
            try:
                conn = pymssql.connect(**config)
                cursor = conn.cursor()
                sql = "delete from pymem where no={}".format(delno)
                cursor.execute(sql)
                conn.commit()
                self.showData()  # 자료 삭제 후 전체자료 출력

            except Exception as e:
                wx.MessageBox("삭제에러 :" + str(e), "에러", wx.OK)

            finally:
                conn.rollback()
                cursor.close()
                conn.close()
        textDlg.Destroy()  # TextEntryDialog E 22/

        def __del__(self):
            pass

if __name__ == '__main__':
        app = wx.App()
        MyFrame1(None).Show()
        app.MainLoop()

