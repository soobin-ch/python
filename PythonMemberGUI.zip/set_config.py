import pickle
config = {
    'server':'127.0.0.1',
    'port':'1433',
    'user':'tester1',
    'password':'pass',
    'database':'test'
}
with open('mssqldb.dat', 'wb') as obj:
    pickle.dump(config, obj)