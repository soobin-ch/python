import wx
import wx.xrc


###########################################################################
## Class MyFrame1
###########################################################################

class MyFrame1(wx.Frame):

    def __init__(self, parent):
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title="미니계산기", pos=wx.DefaultPosition, size=wx.Size(400, 300),
                          style=wx.DEFAULT_FRAME_STYLE | wx.TAB_TRAVERSAL)


        mainSizer = wx.BoxSizer(wx.VERTICAL)

        # -----------------------------
        # 상단 제목 패널
        # -----------------------------
        self.m_panel1 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        titleSizer = wx.BoxSizer(wx.HORIZONTAL)
        self.txtName = wx.StaticText(self.m_panel1, wx.ID_ANY, u"🧮 미니 계산기", wx.DefaultPosition, wx.DefaultSize, 0)
        self.txtName.Wrap(-1)
        titleSizer.Add(self.txtName, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 10)
        self.m_panel1.SetSizer(titleSizer)
        self.m_panel1.Layout()
        mainSizer.Add(self.m_panel1, 0, wx.EXPAND | wx.ALL, 5)

        # -----------------------------
        # 입력 패널
        # -----------------------------
        self.m_panel2 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        inputSizer = wx.BoxSizer(wx.VERTICAL)

        # 숫자1
        self.txtNum1 = wx.TextCtrl(self.m_panel2, wx.ID_ANY, "", wx.DefaultPosition, wx.DefaultSize, 0)
        inputSizer.Add(self.txtNum1, 0, wx.ALL | wx.EXPAND, 5)

        # 연산자 선택
        self.choiceOp = wx.Choice(self.m_panel2, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, ["+", "-", "*", "/"])
        self.choiceOp.SetSelection(0)
        inputSizer.Add(self.choiceOp, 0, wx.ALL | wx.EXPAND, 5)

        # 숫자2
        self.txtNum2 = wx.TextCtrl(self.m_panel2, wx.ID_ANY, "", wx.DefaultPosition, wx.DefaultSize, 0)
        inputSizer.Add(self.txtNum2, 0, wx.ALL | wx.EXPAND, 5)

        # 계산 버튼
        self.btnCalc = wx.Button(self.m_panel2, wx.ID_ANY, u"계산하기", wx.DefaultPosition, wx.DefaultSize, 0)
        inputSizer.Add(self.btnCalc, 0, wx.ALL | wx.EXPAND, 10)

        self.m_panel2.SetSizer(inputSizer)
        self.m_panel2.Layout()
        mainSizer.Add(self.m_panel2, 1, wx.EXPAND | wx.ALL, 5)

        # -----------------------------
        # 결과 출력 패널
        # -----------------------------
        self.m_panel3 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        resultSizer = wx.BoxSizer(wx.HORIZONTAL)

        self.lblResult = wx.StaticText(self.m_panel3, wx.ID_ANY, u"결과: ", wx.DefaultPosition, wx.DefaultSize, 0)
        self.lblResult.Wrap(-1)
        resultSizer.Add(self.lblResult, 1, wx.ALL, 10)

        self.m_panel3.SetSizer(resultSizer)
        self.m_panel3.Layout()
        mainSizer.Add(self.m_panel3, 0, wx.EXPAND | wx.ALL, 5)

        self.SetSizer(mainSizer)
        self.Layout()
        self.Centre(wx.BOTH)

        # 이벤트 바인딩
        self.btnCalc.Bind(wx.EVT_BUTTON, self.onCalc)

    def onCalc(self, event):
        try:
            num1 = float(self.txtNum1.GetValue())
            num2 = float(self.txtNum2.GetValue())
            op = self.choiceOp.GetStringSelection()

            if op == "+":
                result = num1 + num2
            elif op == "-":
                result = num1 - num2
            elif op == "*":
                result = num1 * num2
            elif op == "/":
                if num2 == 0:
                    result = "0으로 나눌 수 없습니다"
                else:
                    result = num1 / num2
            else:
                result = "올바른 연산자 선택 필요"

            self.lblResult.SetLabel(f"결과: {result}")
        except ValueError:
            self.lblResult.SetLabel("숫자를 정확히 입력하세요.")

    def __del__(self):
        pass


###########################################################################
## Run the App
###########################################################################

if __name__ == "__main__":
    app = wx.App(False)
    frame = MyFrame1(None)
    frame.Show(True)
    app.MainLoop()