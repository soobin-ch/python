import wx
import wx.xrc


class MyFrame1(wx.Frame):

    def __init__(self, parent):
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title=u"BMI 계산기", pos=wx.DefaultPosition, size=wx.Size(573, 402),
                          style=wx.DEFAULT_FRAME_STYLE | wx.TAB_TRAVERSAL)

        self.SetSizeHints(wx.DefaultSize, wx.DefaultSize)

        bSizer1 = wx.BoxSizer(wx.VERTICAL)

        # 키 입력 패널
        self.m_panel1 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer5 = wx.BoxSizer(wx.HORIZONTAL)

        self.txtName1 = wx.StaticText(self.m_panel1, wx.ID_ANY, u"키(cm)", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer5.Add(self.txtName1, 0, wx.ALL, 5)

        self.txtHeight = wx.TextCtrl(self.m_panel1, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer5.Add(self.txtHeight, 0, wx.ALL, 5)

        self.m_panel1.SetSizer(bSizer5)
        self.m_panel1.Layout()
        bSizer5.Fit(self.m_panel1)
        bSizer1.Add(self.m_panel1, 1, wx.EXPAND | wx.ALL, 5)

        # 몸무게 입력 패널
        self.m_panel2 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer6 = wx.BoxSizer(wx.HORIZONTAL)

        self.txtName = wx.StaticText(self.m_panel2, wx.ID_ANY, u"몸무게(kg)", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer6.Add(self.txtName, 0, wx.ALL, 5)

        self.txtWeight = wx.TextCtrl(self.m_panel2, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer6.Add(self.txtWeight, 0, wx.ALL, 5)

        self.m_panel2.SetSizer(bSizer6)
        self.m_panel2.Layout()
        bSizer6.Fit(self.m_panel2)
        bSizer1.Add(self.m_panel2, 1, wx.EXPAND | wx.ALL, 5)

        # 버튼들
        bSizer12 = wx.BoxSizer(wx.HORIZONTAL)

        self.btncalc = wx.Button(self, wx.ID_ANY, u"계산", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer12.Add(self.btncalc, 0, wx.ALL, 5)

        self.btninit = wx.Button(self, wx.ID_ANY, u"초기화", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer12.Add(self.btninit, 0, wx.ALL, 5)

        bSizer1.Add(bSizer12, 1, wx.EXPAND, 5)

        # 결과 출력 패널
        self.m_panel3 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        sbSizer3 = wx.StaticBoxSizer(wx.StaticBox(self.m_panel3, wx.ID_ANY, u"결과"), wx.VERTICAL)

        self.txtResult = wx.StaticText(self.m_panel3, wx.ID_ANY, u"", wx.DefaultPosition, wx.DefaultSize, 0)
        sbSizer3.Add(self.txtResult, 0, wx.ALL, 10)

        self.m_panel3.SetSizer(sbSizer3)
        self.m_panel3.Layout()
        sbSizer3.Fit(self.m_panel3)
        bSizer1.Add(self.m_panel3, 1, wx.EXPAND | wx.ALL, 5)

        self.SetSizer(bSizer1)
        self.Layout()
        self.Centre(wx.BOTH)

        # 이벤트 연결
        self.btncalc.Bind(wx.EVT_BUTTON, self.onCalculate)
        self.btninit.Bind(wx.EVT_BUTTON, self.onClear)

    def onCalculate(self, event):
        try:
            height_cm = float(self.txtHeight.GetValue())
            weight_kg = float(self.txtWeight.GetValue())
            height_m = height_cm / 100

            bmi = weight_kg / (height_m ** 2)

            if bmi < 18.5:
                status = "저체중"
            elif 18.5 <= bmi < 23:
                status = "정상"
            elif 23 <= bmi < 25:
                status = "과체중"
            else:
                status = "비만"

            result_text = f"BMI: {bmi:.2f} ({status})"
            self.txtResult.SetLabel(result_text)

        except ValueError:
            self.txtResult.SetLabel("유효한 숫자를 입력하세요.")

    def onClear(self, event):
        self.txtHeight.SetValue("")
        self.txtWeight.SetValue("")
        self.txtResult.SetLabel("")


if __name__ == "__main__":
    app = wx.App(False)
    frame = MyFrame1(None)
    frame.Show()
    app.MainLoop()
