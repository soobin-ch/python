# -------------------- Automobile2 클래스 --------------------
class Automobile2:
    def __init__(self, cartype=''):
        # Constructor
        self.car_type = cartype  # 멤버 변수 1
        self.speed = 0  # 멤버 변수 2


my_car = Automobile2()
my_car.speed = 70
print('내 차의 종류는', my_car.car_type, '현재속도는', my_car.speed)

your_car = Automobile2(cartype='')
your_car.speed = 30
print('당신 차의종류는', your_car.car_type,'현재속도는', your_car.speed)

his_car = Automobile2('')
his_car.speed = 50
print('그의 차 종류는', his_car.car_type,'현재속도는', his_car.speed)

# -------------------- Book 클래스 --------------------
class Book():
    def __init__(self, name, writer, pages):
        self.name = name
        self.writer = writer
        self.pages = pages

    def __str__(self):
        return f"The title of the book is {self.name}"

    def __repr__(self):
        return 'REPR'

    def __len__(self):
        return int(self.pages)

    def __eq__(self, other):
        return (self.name == other.name) & (self.writer == other.writer)


a = Book("Moby Dick", "Herman Melville", "410")
b = Book("The Old Man and the Sea", "Ernest Hemingway", "128")

print(a.writer)
print(b)
print(repr(b))
print(len(b))
print(a == b)

# -------------------- Potato, Apple 클래스 + 함수 --------------------
class Potato:
    def type(self):
        print("Vegetable")

    def color(self):
        print("Yellow")


class Apple:
    def type(self):
        print("Fruit")

    def color(self):
        print("Red")


def func(obj):
    obj.type()
    obj.color()


obj_potato = Potato()
obj_apple = Apple()

func(obj_potato)
func(obj_apple)
# 동일한 함수 func()에 넘기는 인수에 따라
# 다른 결과를 나타냄

# -------------------- for 반복문 다형성 예제 --------------------
for food in (obj_potato, obj_apple):
    food.type()
    food.color()
# 서로 다른 클래스의 객체가 함수 이름이
# 같음을 이용한 다형성

# -------------------- Bird 상속 다형성 예제 --------------------
class Bird:
    def intro(self):
        print("여러 종류의 새가 있다.")
    def flight(self):
        print("대부분의 새는 날지만, 그렇지 못한 새도 있다.")


# Sparrow는 Bird로부터 상속
class Sparrow(Bird):
    def flight(self):
        print("참새는 잘 날 수 있다.")


# Penguin은 Bird로부터 상속
class Penguin(Bird):
    def flight(self):
        print("펭귄은 날 수 없다.")


obj_bird = Bird()
obj_spar = Sparrow()
obj_peng = Penguin()

obj_bird.intro()
obj_bird.flight()

obj_spar.intro()
obj_spar.flight()
# Sparrow flight() = 참새는 잘 날 수 있다.

obj_peng.intro()
obj_peng.flight()
# Penguin flight() = 펭귄은 날 수 없다.
