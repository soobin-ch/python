class Automobile:
    Count = 0  # 클래스 변수

    def __init__(self):
        # 생성자 (Constructor)
        Automobile.Count += 1  # 생성된 자동차 수 1 증가
        self.car_type = '승용차'  # 멤버 변수 1
        self.speed = 0  # 멤버 변수 2

    def __del__(self):
        # 소멸자 (Destructor)
        Automobile.Count -= 1  # 생성된 자동차 수 1 감소

    def speed_up(self, value):
        # 멤버 메서드 (속도 가속)
        self.speed += value
        if self.speed > 100:
            # speed 가 100보다 크면 최대 속도는 100
            self.speed = 100

    def speed_down(self, value):
        # 멤버 메서드 (속도 감속)
        self.speed -= value
        if self.speed < 0:
            # speed 가 0보다 작으면 최소 속도는 0
            self.speed = 0

    def stop(self):
        # 멤버 메서드 (정지)
        self.speed = 0  # 정지시 속도는 0

    @classmethod
    def printCount(cls):
        # 클래스 메서드
        print('자동차 수:', cls.Count)


# 클래스 메서드 호출
Automobile.printCount()

# 자동차 객체(인스턴스) 생성 (생성자 호출)
my_car = Automobile()
print('현재 자동차의 대수:', Automobile.Count)

# 70 가속
my_car.speed_up(70)
# 클래스 변수 직접 참조
print('내 차의 종류는 ', my_car.car_type, '현재 속도는 ', my_car.speed)

# 20 감속
my_car.speed_down(20)
print('내 차의 종류는 ', my_car.car_type, '현재 속도는 ', my_car.speed)

# 정지
my_car.stop()
print('내 차의 종류는 ', my_car.car_type, '현재 속도는 ', my_car.speed)

# 자동차 객체(인스턴스) 추가 생성 (생성자 호출)
your_car = Automobile()

# 클래스 메서드 호출
Automobile.printCount()

# 멤버 변수 직접 변경 (자동차의 종류 지정)
your_car.car_type = '트럭'

# 멤버 변수 직접 변경 (현재 속도 30으로 지정)
your_car.speed = 30

print('당신 차의 종류는 ', your_car.car_type, '현재 속도는 ', your_car.speed)

# 자동차 객체(인스턴스) 폐차하기 (소멸자 호출)
del (your_car)

# 클래스 메서드 호출
Automobile.printCount()

# -----------------------------------

class Cls:
    def fun(self):
        print('Cls call')


# 객체 생성
a = Cls()

# Bound Method Call
a.fun()

# Unbound Method Call
Cls.fun(a)
