# -------------------- SteeringWheel 클래스 --------------------
class SteeringWheel:
    def turn_left(self, quantity):
        self.quantity = quantity
        return '좌회전'

    def turn_right(self, quantity):
        self.quantity = quantity
        return '우회전'


# -------------------- Car 클래스 --------------------
class Car:
    def __init__(self, owner_name):
        self.turnShow = ''  # 멤버 변수 1
        self.owner_name = owner_name  # 멤버 변수 2
        self.steeringWheel = SteeringWheel()  # 멤버 변수 3

    def turn_steeringWheel(self, q):
        if q > 0:
            self.turnShow = self.steeringWheel.turn_right(q)
        elif q < 0:
            self.turnShow = self.steeringWheel.turn_left(q)
        else:
            self.turnShow = '직진'

tom = Car('tom')
tom.turn_steeringWheel(10)
print(tom.owner_name, '', tom.turnShow, str(tom.steeringWheel.quantity))

oscar = Car('oscar')
oscar.turn_steeringWheel(-25)
print(oscar.owner_name, '', oscar.turnShow, str(oscar.steeringWheel.quantity))


# -------------------- Refrigerator 클래스 --------------------
class Refrigerator:
    def __init__(self):
        self.isOpened = False
        self.foods = []

    def open(self):
        if self.isOpened:
            return
        self.isOpened = True
        print('냉장고 문 열기')

    def put(self, thing):
        if self.isOpened:
            self.foods.append(thing)
            print('냉장고 속에', thing, '이(가) 들어감')
            self.list()
        else:
            print('냉장고가 문이 닫혀서 음식을 넣을 수 없음')

    def close(self):
        self.isOpened = False
        print('냉장고 문 닫기')

    def list(self):
        for f in self.foods:
            print('-', f.name, f.expiryDate)





# -------------------- FoodData 클래스 --------------------
class FoodData:
    def __init__(self, name, expiryDate):
        self.name = name
        self.expiryDate = expiryDate

    def __str__(self):
        return self.name + ' ' + self.expiryDate


# -------------------- Refrigerator 객체 생성 및 사용 예제 --------------------
f = Refrigerator()

apple = FoodData('사과', '2023-2-17')
f.open()
f.put(apple)
f.close()

cola = FoodData('콜라', '2024-10-10')
f.open()
f.put(cola)
f.close()
