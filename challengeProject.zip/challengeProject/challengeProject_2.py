from sympy import primerange

# 100 이상 1000 이하 소수 구하기
primes = list(primerange(100, 1001))

# 소수 개수 출력
print("100 이상 1000 이하 소수 개수:", len(primes))


