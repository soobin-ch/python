from primePy import primes

# 100에서 1000 사이의 소수 목록 구하기
prime_list = primes.between(100, 1000)

# 결과 출력
print("100에서 1000 사이의 소수 목록:", prime_list)
print("소수의 개수:", len(prime_list))
