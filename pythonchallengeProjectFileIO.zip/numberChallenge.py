import os

def filessum():
    with open(os.getcwd() + r'\number.txt', 'r', encoding='UTF-8') as fp:

        for line in fp:
            sum = 0.0
            arr = line.strip().split()
            for i in arr:
                sum += float(i)
            print(sum)





filessum()
