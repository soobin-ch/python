import os



def filesearch(keyword):
    with open(os.getcwd() + r'\zipcode.txt', 'r', encoding='UTF-8') as fp:

        for line in fp:
            if keyword in line:
                print(line.strip())
            else:
                continue

userInput = input('enter the keyword:')
filesearch(userInput)










