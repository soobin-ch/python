# turtle 모듈을 사용해 별 모양 패턴 그리기
from turtle import *

color('red', 'yellow')          # 펜의 색은 빨강, 칠하는 색은 노랑
begin_fill()                    # 도형 내부를 칠하는 색 지정

while True:
    forward(200)                # 펜 방향 기준, 앞으로 200px 만큼 이동하며 선을 그린다.
    left(170)                   # 펜의 방향을 시계 반대 방향으로 괄호 안의 값만큼 회전한다.
    if abs(pos()) < 1:          # 현재 위치가 시작점 근처이면 반복 종료
        break

end_fill()                      # 색칠하기 끝을 선언
done()                          # turtle 그래픽 화면의 자동종료를 방지하는 역할을 한다.
