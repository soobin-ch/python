import pygame
import sys

pygame.init()  # pygame 초기화

# 게임 윈도우 설정
windowSurface = pygame.display.set_mode((400, 300))
pygame.display.set_caption('파이게임 에니메이션')

# 게임 화면에 배경색을 흰색으로 설정
windowSurface.fill(color=(255, 255, 255))

# 선 그리기
pygame.draw.line(surface=windowSurface, color=(255, 0, 0), start_pos=(50, 30), end_pos=(100, 30), width=1)
pygame.draw.line(surface=windowSurface, color=(0, 0, 255), start_pos=(50, 50), end_pos=(200, 50), width=3)

# 원 그리기
pygame.draw.circle(surface=windowSurface, color=(255, 0, 0), center=(100, 150), radius=30)

# 삼각형 그리기
pygame.draw.polygon(surface=windowSurface, color=(0, 255, 0), points=((250, 100), (200, 150), (300, 150)))

# 화면 갱신
pygame.display.update()

# 게임 루프 시작
while True:
    for event in pygame.event.get():  # 게임 도중 발생하는 이벤트 처리
        if event.type == pygame.QUIT:  # 윈도우의 닫기 버튼을 누른 경우
            sys.exit()  # 게임 종료


