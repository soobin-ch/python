from flask import Flask  # flask 패키지에서 Flask 클래스를 가져옵니다.

app = Flask(__name__)

@app.route('/')
def hello():
    return "Hello World"

if __name__ == '__main__':
    app.run()
