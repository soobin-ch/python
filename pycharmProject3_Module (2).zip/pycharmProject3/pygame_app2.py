import pygame
import sys

from pygame.examples.grid import WINDOW_WIDTH, WINDOW_HEIGHT

pygame.init()  # pygame 초기화


windowSurface = pygame.display.set_mode((400, 300))
pygame.display.set_caption('파이게임 에니메이션')

# 이미지 불러오기

carImage_raw = pygame.image.load('car.png')
carImage = pygame.transform.scale(carImage_raw, (75, 75))  # 자동차 아이콘을 100x75 크기로 변경


carx = 0  # 이미지 표시용 x좌표
cary = 0  # 이미지 표시용 y좌표

# 이미지 이동 방향 설정
direction = 'right'  # 오른쪽으로 이동 시작
FPS = 30
fpsTimes = pygame.time.Clock()  # 게임 루프의 주기 및 속도를 결정하는 Clock 객체

# 배경 음악 재생
pygame.mixer.music.load('backsound.mp3')  # 배경 음악 파일 읽기 (source 폴더에 제공됨)
pygame.mixer.music.play()  # 배경 음악 재생

while True:  # 게임 루프 처리
    # 게임 스크린 배경은 흰색으로 설정
    windowSurface.fill(color=(255, 255, 255))

    # 자동차 이미지 이동 처리
    if direction == 'right':
        carx += 5  # 오른쪽으로 이동
        if carx >= 300:
            direction = 'down'  # x값이 300이면 아래로 이동

    elif direction == 'down':
        cary += 5  # 아래로 이동
        if cary >= 250:
            direction = 'left'  # y값이 250이면 왼쪽으로 이동

    elif direction == 'left':
        carx -= 5  # 왼쪽으로 이동
        if carx <= 10:
            direction = 'up'  # x값이 10이면 위로 이동

    elif direction == 'up':
        cary -= 5  # 위로 이동
        if cary <= 10:
            direction = 'right'  # y값이 10이면 오른쪽으로 이동

    # 자동차 이미지 화면에 그리기
    windowSurface.blit(carImage, (carx, cary))

    # 화면 갱신
    pygame.display.update()

    # FPS 설정 (프레임 속도 조절)
    fpsTimes.tick(FPS)

    # 종료 이벤트 처리
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

