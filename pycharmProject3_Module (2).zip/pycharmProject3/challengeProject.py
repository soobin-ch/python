import os

def explore_directory(path, depth=0):
    try:
        items = os.listdir(path)
    except PermissionError:
        # 권한이 없으면 건너뛰기
        print("  " * depth + "[접근 불가] :", path)
        return

    for item in items:
        full_path = os.path.join(path, item)
        if os.path.isdir(full_path):
            print("  " * depth + "[디렉터리] :", item)
            explore_directory(full_path, depth + 1)  # 재귀 호출로 하위 폴더 탐색
        else:
            print("  " * depth + "[파일] :", item)

# 시작 디렉터리 (현재 작업 디렉터리)
start_path = os.getcwd()
print("탐색 시작 경로:", start_path)

explore_directory(start_path)
