import requests
from bs4 import BeautifulSoup as bs

# 검색할 키워드
query = '두원공과대학교'

# Naver 뉴스 검색 URL
url = 'https://search.naver.com/search.naver?where=news&sm=tab_jum&query=' + query

# 요청 및 HTML 텍스트 가져오기
response = requests.get(url)
html_text = response.text

# BeautifulSoup 객체 생성
soup = bs(html_text, 'html.parser')

# 뉴스 제목 추출
news_titles = soup.select("span.sds-comps-text-type-headline1")

# 뉴스 제목 출력
for i in news_titles:
    title = i.get_text()
    print(title)
