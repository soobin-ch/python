# mymod1.py

tot = 100

def pr_args(*args):
    print(args)

def pr_univ():
    print('Doowon')

def pr_dept():
    print('Computer')
