# test_module.py

PI = 3.141592

def number_input():
    return float(input("반지름 입력: "))

def get_circumference(radius):
    return 2 * PI * radius

def get_circle_area(radius):
    return PI * radius * radius

print('Module __name__ :', __name__)

if __name__ == '__main__':
    print('Main __name__ :', __name__)


# test_module.py

PI = 3.141592

def number_input():
    return float(input("반지름 입력: "))

def get_circumference(radius):
    return 2 * PI * radius

def get_circle_area(radius):
    return PI * radius * radius

print('Module __name__:', __name__)

if __name__ == '__main__':
    print('주도권은 현재 test_module.py가 가짐')
