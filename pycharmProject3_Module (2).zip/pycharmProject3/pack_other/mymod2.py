# mymod2.py

def sum2(a, b):
    return a + b

def dif2(a, b):
    return a - b

def mul2(a, b):
    return a * b
