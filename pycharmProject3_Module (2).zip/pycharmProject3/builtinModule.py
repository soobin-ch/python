# 시스템 정보 확인
import sys
print(sys.path)        # 모듈 검색 경로 출력
print(sys.version)     # Python 버전 출력

# 수학 함수 사용
import math
print(math.pi)                             # 원주율(pi) 값 출력
print(math.sin(math.radians(30)))          # sin(30°) 값 출력

# 달력 출력하기
import calendar
calendar.setfirstweekday(6)                # 일요일을 첫 요일로 설정
calendar.prmonth(2023, 4)                  # 2023년 4월 달력 출력

# 작업 경로 관련 정보 얻기
import os
print(os.getcwd())                         # 현재 작업 경로 반환
print(os.listdir('/'))                     # root(/) 내의 파일 목록 반환
