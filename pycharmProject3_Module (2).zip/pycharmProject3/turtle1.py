# turtle 모듈을 사용해 그림 그리기
import turtle
a = turtle.Pen()                          # 그림을 그리기 위한 펜을 생성한다.

# 사각형 그리기
a.pendown()                                # 도형 그리기를 위해 펜을 그림판에 내려놓는다.
a.forward(100)                             # 펜의 초기 방향은 오른쪽이며 앞으로 100px만큼 수평 이동하며 선을 그린다.
a.right(90)                                # 시계 방향으로 90도 회전한다. left()는 반대 방향으로 회전한다.
a.forward(100)                             # 앞으로 100px만큼 수평 이동하며 선을 그린다.
a.right(90)
a.forward(100)
a.right(90)
a.forward(100)

# 원 그리기
a.pencolor('blue')                         # 선 색상을 변경
a.pensize(5)
a.circle(50, 360)                          # 원을 그린다. 형식은 circle(반지름, 회전량)이다.

# 글자 쓰기
a.up()                                     # 그리기 작업을 하지 않기 위해 펜을 들어 올린다.
a.forward(100)                             # 원을 그린 후 펜 방향으로 100px 만큼 이동한다.
a.pendown()                                # 그리기를 위해 펜을 그림판에 내려놓는다.
a.write('문자 그리기', True, 'left', ('돋움', 24, 'normal'))   # 글자를 그림판에 쓴다.

turtle.done()                              # turtle 그래픽 화면의 자동종료를 방지하는 역할을 한다.
