# Chap04/module_import.py

# sys.path에 설정된 경로에 모듈 또는 패키지가 있는 경우

# 모듈이 있는 경우
# import mymod1
# print(mymod1.tot)
# mymod1.pr_univ()

# 패키지가 있는 경우
import pack.mymod1

pack.mymod1.pr_args([1, 2], [3, 4])
pack.mymod1.pr_dept()

# 패키지명을 거치지 않고 호출/참조하려면
from pack_other import mymod2

print(mymod2.sum2(1, 2))
print(mymod2.dif2(3, 5))

# 패키지명, 모듈명을 거치지 않고 호출/참조하려면
from pack_other.mymod2 import dif2, mul2

print(dif2(1, 1), mul2(3, 4))

# sys.path에 지정되지 않은 경로에 있는 경우
import sysy

sys.path.append(r'C:\Work')     # 새로운 경로 추가
print(sys.path[-1])             # 추가한 경로 출력

import mymod3

print('나누기', mymod3.div(2, 3))
