# os 모듈을 사용해 현재 디렉터리 내 파일 및 폴더 목록 확인
import os

output = os.listdir()                       # 현재 작업 디렉터리의 파일 및 폴더 목록 반환
print("os.listdir() :", output)

for path in output:
    if os.path.isdir(path):                 # path가 디렉터리인 경우
        print("[디렉터리] :", path)
    else:                                    # path가 파일인 경우
        print("[파일] :", path)
