# importer.py

import test_modulr as test

radius = test.number_input()

print('원둘레 :', test.get_circumference(radius))
print('원면적 :', test.get_circle_area(radius))
