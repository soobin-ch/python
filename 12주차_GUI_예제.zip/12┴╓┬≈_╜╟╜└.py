import wx

list_data = [('홍길동', '서울', '2000'),
             ('전우치', '경기', '2001'),
             ('성춘향', '전북', '2002'),
             ('박문수', '경북', '2003')]

class MyFrame(wx.Frame):
    def __init__(self, parent, title):
        # 윈도우의 창 너비, 높이 설정
        super(MyFrame, self).__init__(parent, title=title, size=(400, 300))

        # wx.ListCtrl 생성
        self.dataList = wx.ListCtrl(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.LC_REPORT)

        # 표의 각 컬럼(0,1,2)의 이름, 너비 설정
        self.dataList.InsertColumn(0, '이름', width=100)
        self.dataList.InsertColumn(1, '출생지', width=100)
        self.dataList.InsertColumn(2, '출생연도', width=100)

        self.Center()  # 창을 화면의 중앙에 위치시킴

        # list_data에서 데이터를 삽입
        for data in list_data:
            # 새로운 행으로 dataList에 추가하고, 그 행번호를 index로 함
            index = self.dataList.InsertItem(self.dataList.GetItemCount(), data[0])
            # index행의 1, 2번 컬럼의 아이템 설정
            self.dataList.SetItem(index, 1, data[1])
            self.dataList.SetItem(index, 2, data[2])

if __name__ == '__main__':
    app = wx.App(False)  # False는 콘솔 출력 안하도록 설정
    MyFrame(None, '리스트 컨트롤 예시').Show()  # 창 제목을 명시
    app.MainLoop()  # 이벤트 루프 시작
