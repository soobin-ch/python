import wx

class ExFrame(wx.Frame):
    def __init__(self, parent, title):
        super(ExFrame, self).__init__(parent, title=title, size=(300, 250))
        panel = wx.Panel(self)  # Panel은 컨트롤을 포함하는 컨테이너

        # Label 설정
        wx.StaticText(panel, label='메세지1: ', pos=(10, 5))
        wx.StaticText(panel, label='메세지2: ', pos=(10, 40))

        # Text Box 설정
        self.txtA = wx.TextCtrl(panel, pos=(70, 5))
        self.txtB = wx.TextCtrl(panel, pos=(70, 40))

        # 메뉴 바 설정
        menuBar = wx.MenuBar()

        # 메뉴(mnuFile)를 만들고 서브메뉴를 추가
        mnuFile = wx.Menu()
        mnuNew = mnuFile.Append(wx.ID_NEW, '새로 만들기')
        mnuOpen = mnuFile.Append(wx.ID_OPEN, '열기 \tCtrl+O')
        mnuFile.AppendSeparator()
        mnuExit = mnuFile.Append(wx.ID_EXIT, '종료')

        # 메뉴바에 mnuFile을 주메뉴로 등록
        menuBar.Append(mnuFile, '파일(&F)')
        self.SetMenuBar(menuBar)  # 메뉴바 설정

        # 각 메뉴를 event handler에 연결
        self.Bind(wx.EVT_MENU, self.OnEvent1, mnuNew)
        self.Bind(wx.EVT_MENU, self.OnEvent2, mnuOpen)
        self.Bind(wx.EVT_MENU, self.OnEvent3, mnuExit)

        # 버튼(1,2)을 만들고, event handler에 연결
        btn1 = wx.Button(panel, label='1', pos=(10, 100))
        btn2 = wx.Button(panel, label='2', pos=(100, 100))
        btn1.Bind(wx.EVT_BUTTON, self.OnBtn1)
        btn2.Bind(wx.EVT_BUTTON, self.OnBtn2)

        # 버튼(3,4)을 만들고, 동일 event handler에 연결
        btn3 = wx.Button(panel, label='3', pos=(10, 150))
        btn4 = wx.Button(panel, label='4', pos=(100, 150))
        btn3.Bind(wx.EVT_BUTTON, self.OnBtnProcess)
        btn4.Bind(wx.EVT_BUTTON, self.OnBtnProcess)
        btn3.id = 1
        btn4.id = 2

        self.Center()  # 이 프레임을 화면의 중앙에 위치시킴

    # Event handler
    def OnEvent1(self, event):
        self.txtB.SetValue('새문서 메뉴 선택')  # SetLabelText -> SetValue
        self.txtA.SetValue('')  # SetLabelText -> SetValue

    def OnEvent2(self, event):
        self.txtA.SetValue('')  # SetLabelText -> SetValue
        self.txtB.SetValue('열기 메뉴 선택')  # SetLabelText -> SetValue

    def OnEvent3(self, event):
        self.Close()

    def OnBtn1(self, event):
        self.txtA.SetValue('버튼1 선택')  # SetLabelText -> SetValue

    def OnBtn2(self, event):
        self.txtA.SetValue('버튼2 선택')  # SetLabelText -> SetValue

    def OnBtnProcess(self, event):
        if event.GetEventObject().id == 1:
            self.txtB.SetValue('버튼3 선택')  # SetLabelText -> SetValue
        elif event.GetEventObject().id == 2:
            self.txtB.SetValue('버튼4 선택')  # SetLabelText -> SetValue

if __name__ == '__main__':
    app = wx.App(False)
    ExFrame(None, '윈도우 연습').Show()
    app.MainLoop()