# -*- coding: utf-8 -*-
import wx

class MyFrame1(wx.Frame):
    def __init__(self, parent):
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title="정보 입력", pos=wx.DefaultPosition, size=wx.Size(300, 200),
                          style=wx.DEFAULT_FRAME_STYLE | wx.TAB_TRAVERSAL)

        self.SetSizeHints(wx.DefaultSize, wx.DefaultSize)

        mainSizer = wx.BoxSizer(wx.VERTICAL)

        # 이름 입력
        panel1 = wx.Panel(self)
        hSizer1 = wx.BoxSizer(wx.HORIZONTAL)

        self.lblName = wx.StaticText(panel1, label="이름: ")
        hSizer1.Add(self.lblName, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5)

        self.txtName = wx.TextCtrl(panel1)
        hSizer1.Add(self.txtName, 1, wx.ALL, 5)

        panel1.SetSizer(hSizer1)
        mainSizer.Add(panel1, 0, wx.EXPAND | wx.ALL, 5)

        # 나이 입력 및 버튼
        panel2 = wx.Panel(self)
        hSizer2 = wx.BoxSizer(wx.HORIZONTAL)

        self.lblAge = wx.StaticText(panel2, label="나이: ")
        hSizer2.Add(self.lblAge, 0, wx.ALL | wx.ALIGN_CENTER_VERTICAL, 5)

        self.txtAge = wx.TextCtrl(panel2)
        hSizer2.Add(self.txtAge, 1, wx.ALL, 5)

        self.btnSubmit = wx.Button(panel2, label="확인")
        hSizer2.Add(self.btnSubmit, 0, wx.ALL, 5)

        panel2.SetSizer(hSizer2)
        mainSizer.Add(panel2, 0, wx.EXPAND | wx.ALL, 5)

        # 결과 표시
        panel3 = wx.Panel(self)
        vSizer3 = wx.BoxSizer(wx.VERTICAL)

        self.lblResult = wx.StaticText(panel3, label="결과보기")
        vSizer3.Add(self.lblResult, 0, wx.ALL, 5)

        panel3.SetSizer(vSizer3)
        mainSizer.Add(panel3, 0, wx.EXPAND | wx.ALL, 5)

        self.SetSizer(mainSizer)
        self.Layout()
        self.Centre(wx.BOTH)

        # 이벤트 연결
        self.btnSubmit.Bind(wx.EVT_BUTTON, self.ShowData)

    def ShowData(self, event):
        name = self.txtName.GetValue()
        age = self.txtAge.GetValue()
        self.lblResult.SetLabelText(f"이름: {name}, 나이: {age}")

# 실행 코드
if __name__ == "__main__":
    app = wx.App(False)
    frame = MyFrame1(None)
    frame.Show()
    app.MainLoop()
