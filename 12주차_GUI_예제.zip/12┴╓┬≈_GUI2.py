import wx
import wx.xrc


class MyFrame1(wx.Frame):

    def __init__(self, parent):
        wx.Frame.__init__(self, parent, id=wx.ID_ANY, title="거래처 등록", pos=wx.DefaultPosition, size=wx.Size(500, 300),
                          style=wx.DEFAULT_FRAME_STYLE | wx.TAB_TRAVERSAL)

        self.SetSizeHints(wx.DefaultSize, wx.DefaultSize)

        bSizer4 = wx.BoxSizer(wx.VERTICAL)

        # Panel 1: 입력
        self.m_panel1 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer5 = wx.BoxSizer(wx.HORIZONTAL)

        self.txtName = wx.StaticText(self.m_panel1, wx.ID_ANY, u"거래처명: ", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer5.Add(self.txtName, 0, wx.ALL, 5)

        self.m_textCtrl1 = wx.TextCtrl(self.m_panel1, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer5.Add(self.m_textCtrl1, 1, wx.ALL, 5)

        self.txtTel = wx.StaticText(self.m_panel1, wx.ID_ANY, u"전화: ", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer5.Add(self.txtTel, 0, wx.ALL, 5)

        self.m_textCtrl2 = wx.TextCtrl(self.m_panel1, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer5.Add(self.m_textCtrl2, 1, wx.ALL, 5)

        self.btnInsert = wx.Button(self.m_panel1, wx.ID_ANY, u"등록", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer5.Add(self.btnInsert, 0, wx.ALL, 5)

        self.m_panel1.SetSizer(bSizer5)
        self.m_panel1.Layout()
        bSizer5.Fit(self.m_panel1)
        bSizer4.Add(self.m_panel1, 0, wx.ALL | wx.EXPAND, 5)

        # Panel 2: 리스트
        self.m_panel2 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer6 = wx.BoxSizer(wx.VERTICAL)

        self.m_listCtrl2 = wx.ListCtrl(self.m_panel2, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.LC_REPORT)
        self.m_listCtrl2.InsertColumn(0, "거래처명", width=200)
        self.m_listCtrl2.InsertColumn(1, "전화", width=150)

        bSizer6.Add(self.m_listCtrl2, 1, wx.ALL | wx.EXPAND, 5)

        self.m_panel2.SetSizer(bSizer6)
        self.m_panel2.Layout()
        bSizer6.Fit(self.m_panel2)
        bSizer4.Add(self.m_panel2, 1, wx.EXPAND | wx.ALL, 5)

        # Panel 3: 개수
        self.m_panel3 = wx.Panel(self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL)
        bSizer7 = wx.BoxSizer(wx.HORIZONTAL)

        self.m_staticText3 = wx.StaticText(self.m_panel3, wx.ID_ANY, u"거래처 수 :", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer7.Add(self.m_staticText3, 0, wx.ALL, 5)

        self.lblCount = wx.StaticText(self.m_panel3, wx.ID_ANY, u"0", wx.DefaultPosition, wx.DefaultSize, 0)
        bSizer7.Add(self.lblCount, 0, wx.ALL, 5)

        self.m_panel3.SetSizer(bSizer7)
        self.m_panel3.Layout()
        bSizer7.Fit(self.m_panel3)
        bSizer4.Add(self.m_panel3, 0, wx.EXPAND | wx.ALL, 5)

        self.SetSizer(bSizer4)
        self.Layout()
        self.Centre(wx.BOTH)

        # Connect Events
        self.btnInsert.Bind(wx.EVT_BUTTON, self.OnInsert)

    def __del__(self):
        pass

    def OnInsert(self, event):
        name = self.m_textCtrl1.GetValue().strip()
        tel = self.m_textCtrl2.GetValue().strip()

        if name and tel:
            index = self.m_listCtrl2.InsertItem(self.m_listCtrl2.GetItemCount(), name)
            self.m_listCtrl2.SetItem(index, 1, tel)

            # 거래처 수 갱신
            count = self.m_listCtrl2.GetItemCount()
            self.lblCount.SetLabel(str(count))

            # 입력 필드 초기화
            self.m_textCtrl1.SetValue("")
            self.m_textCtrl2.SetValue("")
        else:
            wx.MessageBox("모든 항목을 입력하세요.", "입력 오류", wx.OK | wx.ICON_WARNING)
if __name__ == "__main__":
    app = wx.App(False)          # 앱 객체 생성
    frame = MyFrame1(None)       # 프레임(창) 생성
    frame.Show()                 # 프레임 표시
    app.MainLoop()               # 메인 이벤트 루프 시작