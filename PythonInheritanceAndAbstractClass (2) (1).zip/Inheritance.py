# -------------------- Animal, Dog, Horse 클래스 --------------------
class Animal:  # parent class (super class)
    def move(self):
        print('움직이는 생물')


class Dog(Animal):  # child class (sub class)
    def my(self):
        print('나는 멍멍이')


class Horse(Animal):  # child class
    pass


dog1 = Dog()
dog1.my()       # 자기 클래스의 메서드 호출
dog1.move()     # 부모 클래스의 메서드 호출

horse1 = Horse()
horse1.move()   # 부모 클래스의 메서드 호출


# -------------------- Person, Employee 클래스 --------------------
class Person:  # 수퍼클래스
    def __init__(self, age):
        print('Person 생성자')
        self.age = age
        self.say = '난 사람~'

    def print_info(self):
        print('say: {}, age: {}'.format(self.say, self.age))


class Employee(Person):
    def __init__(self):
        print('Employee 생성자')
        super().__init__(20)  # 부모 클래스 생성자 호출 (항상 20세)
        self.say = '일하는 사람'  # 부모와 같은 이름의 멤버 변수
        self.subject = '근로자'  # Employee만의 고유 멤버 변수

    def eprint_info(self):
        self.print_info()
        super().print_info()
        print(self.say)

    def print_info(self):  # Overriding
        print('오버라이딩 in Employee')


# -------------------- Worker, Programmer 클래스 --------------------
class Worker(Person):
    def __init__(self, age):
        print('Worker 생성자')
        super().__init__(age)

    def wprint_info(self):
        self.print_info()


class Programmer(Worker):
    def __init__(self, age):
        print('Programmer 생성자')
        super().__init__(age)  # Bound call
        Worker.__init__(self, age)  # Unbound call

    def pprint_info(self):
        self.print_info()
        super().print_info()
        # 호출 순서: Programmer → Worker → Person


# -------------------- Person, Employee, Worker, Programmer 객체 생성 및 사용 --------------------
person = Person('22')
person.print_info()

print('Employee 클래스 처리')
empl = Employee()
print(empl.say, empl.age, empl.subject)
empl.eprint_info()
print('worker 클래스 처리')


work = Worker('31')
print(work.say, work.age)
work.wprint_info()

print('-----Programmer #21')
pr = Programmer('33')
print(pr.say, pr.age)
pr.pprint_info()


# -------------------- Appliance, Tv, Radio 클래스 --------------------
class Appliance:
    def __init__(self):
        self.volume = 0

    def volume_control(self, volume):
        pass


class Tv(Appliance):
    def volume_control(self, volume):
        self.volume += volume
        print('TV 소리:', self.volume)


class Radio(Appliance):
    def show_product(self):
        print('라디오 고유의 메서드')

    def volume_control(self, volume):
        self.volume += volume
        print('Radio 소리:', self.volume)


tv = Tv()
tv.volume_control(5)
tv.volume_control(-3)

rdo = Radio()
rdo.volume_control(7)
rdo.show_product()

app = tv
app.volume_control(3)
app = rdo
rdo.volume_control(3)


# -------------------- Donkey, Horse, Mule, Hinny 클래스 --------------------
class Donkey:
    def __init__(self):
        self.data = '47'

    def skill(self):
        print('당나귀: 짐나르기')


class Horse:
    def skill(self):
        print('말: 달리기')

    def hobby(self):
        print('말은 달리기가 취미')


class Mule(Donkey, Horse):
    def __init__(self):
        super().__init__()
        self.data = ''


class Hinny(Horse, Donkey):
    def skill(self):
        print('버새: 별로 쓸모 없음')
        super().skill()


# -------------------- 객체 생성 및 메서드 호출 --------------------
mu1 = Mule()
mu1.skill()
mu1.hobby()

mu2 = Hinny()
mu2.skill()



from abc import *

# -------------------- Employee 클래스 (추상 클래스) --------------------
class Employee(metaclass=ABCMeta):
    def __init__(self, name, age):
        self.name = name
        self.age = age

    @abstractmethod
    def pay(self):
        pass

    @abstractmethod
    def data_print(self):
        pass

    def nameage_print(self):
        print('이름:' + self.name + ', 나이: ' + str(self.age), end=' ')


# -------------------- Temporary 클래스 (상속) --------------------
class Temporary(Employee):
    def __init__(self, name, age, days, daypay):
        super().__init__(name, age)
        self.days = days
        self.daypay = daypay

    def pay(self):
        return self.days * self.daypay

    def data_print(self):
        self.nameage_print()
        print('급여:', self.pay())


# -------------------- Regular 클래스 (상속) --------------------
class Regular(Employee):
    def __init__(self, name, age, salary):
        super().__init__(name, age)
        self.salary = salary

    def pay(self):
        return self.salary

    def data_print(self):
        self.nameage_print()
        print('월급:', self.pay())


# -------------------- 객체 생성 및 메서드 호출 --------------------
t = Temporary('홍길동', 25, 20, 150000)
r = Regular('이순신', 27, 3500000)

t.data_print()
r.data_print()
